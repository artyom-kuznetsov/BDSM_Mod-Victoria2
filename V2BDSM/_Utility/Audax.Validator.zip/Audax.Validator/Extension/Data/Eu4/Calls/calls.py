

class Exports:
	pass

Exports.AllScopes = ['Country', 'Province', 'State', 'Global', 'Unit']

EXPORT = {
	'KEY': 'calls',
	'VALUE': Exports
}
